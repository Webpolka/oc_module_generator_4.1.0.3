# Start Module Template

**Opencart 4.1.0.3 – January 2026**  

This is a **starter template** to quickly create your **custom OpenCart module**.  
It sets up:

- Admin and Catalog structure  
- Placeholder replacement (`%name%`, `%ModuleName%`)  
- Ready-to-use file structure and ZIP for OCMOD installation  

## Usage

1. Copy the `files/` template  
2. Run the generator with your module name  
3. Get ready-to-install OCMOD ZIP for OpenCart  

> Start building your own module in minutes, fully compatible with OpenCart 4.1.0.3.
