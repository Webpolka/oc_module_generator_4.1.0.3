<?php
$_['heading_title'] = '%ModuleName%';